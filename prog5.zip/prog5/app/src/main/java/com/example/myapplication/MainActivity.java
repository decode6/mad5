package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText e1,e2;
    private Button log_button,reg_button;
    private SQLiteHelper helper;
    private String user_name,password,temp_pass;
    private SQLiteDatabase database;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=findViewById(R.id.editTextTextPersonName);
        e2=findViewById(R.id.editTextTextPassword);
        log_button=findViewById(R.id.button);
        reg_button=findViewById(R.id.button2);

        helper=new SQLiteHelper(getBaseContext(),"userdb",null,1);
        helper.queryData("create table if not exists users(name varchar,pass varchar)");

        log_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                user_name=e1.getText().toString();
                password=e2.getText().toString();
                try {
                    helper=new SQLiteHelper(getBaseContext(),"userdb",null,1);
                    final String path=getApplicationContext().getDatabasePath("userdb").getPath();
                    database=SQLiteDatabase.openOrCreateDatabase(path,null);
                    Cursor cursor=database.rawQuery("select pass from users where name= '"+user_name+"'",null);
                    while(cursor.moveToNext()){
                        temp_pass=cursor.getString(0);
                    }
                    if (temp_pass.equals(password)){
                        Toast.makeText(MainActivity.this,"Loggin in ",Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(MainActivity.this,"Incorrect Crediantials",Toast.LENGTH_SHORT).show();
                    }
                }
                catch (Exception e){
                    System.out.println(e.toString());
                }

            }
        });


        reg_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,Registeration.class);
                startActivity(intent);

            }
        });

    }
}